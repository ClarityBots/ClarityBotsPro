#!/bin/bash

# Usage: ./build-release.sh v1.2.0
# OR:    npm run build:release v1.2.0

VERSION=$1

if [ -z "$VERSION" ]; then
  echo "❌ Please provide a version number (e.g., ./build-release.sh v1.1.0)"
  exit 1
fi

ZIP_NAME="ClarityBots-$VERSION.zip"

echo "📦 Creating release archive: $ZIP_NAME"

# Exclude .git, .DS_Store, previous zips
zip -r "$ZIP_NAME" . \
  -x "*.git*" \
  -x "*.DS_Store" \
  -x "ClarityBots-*.zip" \
  -x "node_modules/*"

echo "✅ $ZIP_NAME created successfully!"